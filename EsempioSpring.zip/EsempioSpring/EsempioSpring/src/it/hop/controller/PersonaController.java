package it.hop.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import it.hop.applicationcontext.AppContext;
import it.hop.oggetti.Persona;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PersonaController implements Controller {

	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		ApplicationContext ctx = AppContext.getApplicationContext();
		Persona mario = (Persona) ctx.getBean("Mario");

		String aMessage = "Ciao questa è la classe PersonaController, "
				+ mario.getAnagrafica().getCognome() + " abita a "
				+ mario.getResidenza().getCitta();

		ModelAndView modelAndView = new ModelAndView("persona");
		modelAndView.addObject("message", aMessage);

		return modelAndView;
	}

}
