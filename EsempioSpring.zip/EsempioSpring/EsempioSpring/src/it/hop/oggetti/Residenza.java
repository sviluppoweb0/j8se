package it.hop.oggetti;

public class Residenza {
	private String via;
	private String citta;
	private String nazione;

	public Residenza() {
		super();
	}
	
	public Residenza(String via, String citta, String nazione) {
		super();
		this.via = via;
		this.citta = citta;
		this.nazione = nazione;
	}

	public String getVia() {
		return via;
	}
	public void setVia(String via) {
		this.via = via;
	}
	public String getCitta() {
		return citta;
	}
	public void setCitta(String citta) {
		this.citta = citta;
	}
	public String getNazione() {
		return nazione;
	}
	public void setNazione(String nazione) {
		this.nazione = nazione;
	}
}
