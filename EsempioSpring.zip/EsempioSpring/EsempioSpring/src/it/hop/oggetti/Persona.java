package it.hop.oggetti;

public class Persona {
	
	private Anagrafica anagrafica;
	private Residenza residenza;
	
	
	public Persona() {
		super();
	}
	
	public Persona(Anagrafica anagrafica, Residenza residenza) {
		super();
		this.anagrafica = anagrafica;
		this.residenza = residenza;
	}

	public Anagrafica getAnagrafica() {
		return anagrafica;
	}
	public void setAnagrafica(Anagrafica anagrafica) {
		this.anagrafica = anagrafica;
	}
	public Residenza getResidenza() {
		return residenza;
	}
	public void setResidenza(Residenza residenza) {
		this.residenza = residenza;
	}
}
