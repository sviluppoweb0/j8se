package it.html.spring.book;

import java.util.List;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

public class BookHibernateDaoSupport extends HibernateDaoSupport implements BookDao{
	
	  @Transactional	
	  public int bookCount() {
	    return findAllBooks().size();		
	  }

	  @Transactional
	  public void delete(String isbn) {
	    Book book = (Book) getHibernateTemplate().get(Book.class, isbn);
	    getHibernateTemplate().delete(book);
	  }

	  @Transactional(readOnly = true)
	  public List<Book> findAllBooks() {
	    return getHibernateTemplate().find("from Book");
	  }

	  @Transactional(readOnly = true)
	  public Book findByISBN(String isbn) {		
	    return (Book) getHibernateTemplate().get(Book.class, isbn);
	  }

	  @Transactional
	  public void insert(Book book) {
	    getHibernateTemplate().saveOrUpdate(book);
	  }

	  public void update(Book book) {
	    getHibernateTemplate().saveOrUpdate(book);	
	  }
	}
