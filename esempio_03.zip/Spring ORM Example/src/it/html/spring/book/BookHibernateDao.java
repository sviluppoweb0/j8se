package it.html.spring.book;

import java.util.List;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

public class BookHibernateDao implements BookDao{

	private HibernateTemplate hibernateTemplate;
	
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
	@Transactional	
	public int bookCount() {
		return findAllBooks().size();		
	}

	@Transactional
	public void delete(String isbn) {
		Book book = (Book) hibernateTemplate.get(Book.class, isbn);
		hibernateTemplate.delete(book);
	}

	@Transactional(readOnly = true)
	public List<Book> findAllBooks() {
		return hibernateTemplate.find("from Book");
	}

	@Transactional
	public Book findByISBN(String isbn) {		
		return (Book) hibernateTemplate.get(Book.class, isbn);
	}

	@Transactional
	public void insert(Book book) {
		hibernateTemplate.saveOrUpdate(book);
	}

	@Transactional
	public void update(Book book) {
		hibernateTemplate.saveOrUpdate(book);	
	}
}
