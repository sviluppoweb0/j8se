package it.html.spring.book;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public class BookJdbcDao implements BookDao {

	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	// Inserimento
	public void insert(Book book) {
		jdbcTemplate.update(
				"insert into books (isbn, author, title) values (?, ?, ?)",
				new Object[] { book.getIsbn(), book.getAuthor(),
						book.getTitle() });
	}

	// Modifica
	public void update(Book book) {
		jdbcTemplate.update(
				"update books set author = ?, title = ? where isbn = ?",
				new Object[] { book.getIsbn(), book.getAuthor(),
						book.getTitle() });
	}

	// Eliminazione
	public void delete(String isbn) {
		jdbcTemplate.update("delete from books where isbn = ?",
				new Object[] { isbn });
	}

	// Query di un intero
	public int bookCount() {
		int rowCount = jdbcTemplate.queryForInt("select count(1) from books");
		return rowCount;
	}

	// Query di un singolo oggetto
	public Book findByISBN(String isbn) {
		Book book = (Book) jdbcTemplate.queryForObject(
				"select * from books where isbn = ?", new Object[] { isbn },
				new BookRowMapper());
		return book;
	}

	// Query di una lista
	public List<Book> findAllBooks() {
		List<Book> books = (List<Book>) jdbcTemplate.query(
				"select * from books", new BookRowMapper());
		return books;
	}

}