package it.html.spring.book;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.simple.ParameterizedBeanPropertyRowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class BookJdbcDaoSupport extends JdbcDaoSupport implements BookDao {

	// Inserimento
	public void insert(Book book) {
		getJdbcTemplate().update(
				"insert into books (isbn, author, title) values (?, ?, ?)",
				new Object[] { book.getIsbn(), book.getAuthor(),
						book.getTitle() });
	}

	// Modifica
	public void update(Book book) {
		getJdbcTemplate().update(
				"update books set author = ?, title = ? where isbn = ?",
				new Object[] { book.getAuthor(), book.getTitle(),
						book.getIsbn() });
	}

	// Eliminazione
	public void delete(String isbn) {
		getJdbcTemplate().update("delete from books where isbn = ?",
				new Object[] { isbn });
	}

	// Query di un intero
	public int bookCount() {
		int rowCount = getJdbcTemplate().queryForInt(
				"select count(1) from books");
		return rowCount;
	}

	// Query di un singolo oggetto
	public Book findByISBN(String isbn) {
		Book book = (Book) getJdbcTemplate().queryForObject(
				"select * from books where isbn = ?", new Object[] { isbn },
				new BeanPropertyRowMapper(Book.class));
		return book;
	}

	// Query di una lista di oggetti
	public List<Book> findAllBooks() {
		List<Book> books = (List<Book>) getJdbcTemplate().query(
				"select * from books",
				ParameterizedBeanPropertyRowMapper.newInstance(Book.class));
		return books;
	}

}
