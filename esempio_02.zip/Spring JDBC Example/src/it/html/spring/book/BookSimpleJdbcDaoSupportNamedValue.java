package it.html.spring.book;

import java.util.List;

import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.ParameterizedBeanPropertyRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

public class BookSimpleJdbcDaoSupportNamedValue extends SimpleJdbcDaoSupport
		implements BookDao {

	// Inserimento
	public void insert(Book book) {
		// Binding automatico dei parametri
		SqlParameterSource parameters = new BeanPropertySqlParameterSource(book);
		// Inserimento
		getSimpleJdbcTemplate()
				.update(
						"insert into books (isbn, author, title) values (:isbn, :author, :title)",
						parameters);
	}

	// Modifica
	public void update(Book book) {
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("isbn", book.getIsbn());
		parameters.addValue("author", book.getAuthor());
		parameters.addValue("title", book.getTitle());
		getSimpleJdbcTemplate()
				.update(
						"update books set author = :author, title = :title where isbn = :isbn",
						parameters);
	}

	// Eliminazione
	public void delete(String isbn) {
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("isbn", isbn);
		getSimpleJdbcTemplate().update("delete from books where isbn = :isbn",
				parameters);
	}

	// Query di un intero
	public int bookCount() {
		int rowCount = getJdbcTemplate().queryForInt(
				"select count(1) from books");
		return rowCount;
	}

	// Query di un singolo oggetto
	public Book findByISBN(String isbn) {
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("isbn", isbn);
		Book book = getSimpleJdbcTemplate().queryForObject(
				"select * from books where isbn = :isbn",
				ParameterizedBeanPropertyRowMapper.newInstance(Book.class),
				parameters);
		return book;
	}

	// Query di una lista di oggetti
	public List<Book> findAllBooks() {
		List<Book> books = getSimpleJdbcTemplate().query("select * from books",
				ParameterizedBeanPropertyRowMapper.newInstance(Book.class));
		return books;
	}

}
