package it.html.spring.book;

import java.util.List;

import org.springframework.jdbc.core.simple.ParameterizedBeanPropertyRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

public class BookSimpleJdbcDaoSupport extends SimpleJdbcDaoSupport implements
		BookDao {

	// Inserimento
	public void insert(Book book) {
		getSimpleJdbcTemplate().update(
				"insert into books (isbn, author, title) values (?, ?, ?)",
				book.getIsbn(), book.getAuthor(), book.getTitle());
	}

	// Modifica
	public void update(Book book) {
		getSimpleJdbcTemplate().update(
				"update books set author = ?, title = ? where isbn = ?",
				book.getAuthor(), book.getTitle(), book.getIsbn());
	}

	// Eliminazione
	public void delete(String isbn) {
		getSimpleJdbcTemplate()
				.update("delete from books where isbn = ?", isbn);
	}

	// Query di un intero
	public int bookCount() {
		int rowCount = getJdbcTemplate().queryForInt(
				"select count(1) from books");
		return rowCount;
	}

	// Query di un singolo oggetto
	public Book findByISBN(String isbn) {
		Book book = getSimpleJdbcTemplate().queryForObject(
				"select * from books where isbn = ?",
				ParameterizedBeanPropertyRowMapper.newInstance(Book.class),
				isbn);
		return book;
	}

	// Query di una lista di oggetti
	public List<Book> findAllBooks() {
		List<Book> books = (List<Book>) getJdbcTemplate().query("select * from books",
				ParameterizedBeanPropertyRowMapper.newInstance(Book.class));
		return books;
	}

}
