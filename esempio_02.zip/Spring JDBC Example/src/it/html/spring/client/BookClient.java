package it.html.spring.client;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import it.html.spring.book.Book;
import it.html.spring.book.BookDao;


public class BookClient {
	public static void main(String[] args) {
		
	    BeanFactory ctx = new XmlBeanFactory(new ClassPathResource("beans.xml"));														
	    BookDao bookDao = (BookDao)ctx.getBean("bookDao");
	    
	    // Delete
	    bookDao.delete("1234567890123");
	    bookDao.delete("1234567890321");
	    	    
	    //Insert Promessi Sposi
	    Book book = new Book();
	    book.setIsbn("1234567890123");
	    book.setAuthor("Manzoni");
	    book.setTitle("I Promessi Sposi");	    
	    bookDao.insert(book);
	    System.out.println("Inserito:\t" + book);
	    	    	    
	    // Insert Il Barone Rampante
	    book = new Book();
	    book.setIsbn("1234567890321");
	    book.setAuthor("Italo Calvino");
	    book.setTitle("Il Barone Rampante");	    
	    bookDao.insert(book);
	    System.out.println("Inserito:\t" + book);
	    
	    //Find Promessi Sposi
	    book = bookDao.findByISBN("1234567890123");
	    System.out.println("Trovato:\t" + book);
	    	  
	    //Update Promessi Sposi
	    book.setAuthor("Alessandro Manzoni");
	    bookDao.update(book);
	    System.out.println("Modificato:\t" + book);
	    
	    int rowCount = bookDao.bookCount();
	    System.out.println("Numero Libri: " + rowCount);  
	    
	    System.out.println("Lista Libri:");
	    List<Book> books = bookDao.findAllBooks();
	    for (Book b : books)
	    	System.out.println("\t\t"+b);	    	    	    	    		    	    	    	    	 
	}	
}
